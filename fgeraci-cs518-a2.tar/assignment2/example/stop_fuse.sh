fusermount -u mountdir
